"""Full Canada-wide rebuild for the daily job: fetch/refresh data, run every
pipeline, rebuild every map + daily radar + the combined app + priority front page
+ regions hub. Large source data is re-fetched when absent (kept out of git); small
geology facts / boundaries / snapshots are read from data/keep/. Every region is
guarded so one jurisdiction failing can't stop the others or the site build."""
import os
import shutil
import traceback
import ingest
import on_ingest
import on_prep
import pipeline
import build_map
import build_app
import daily
import build_site
from build_map import BC_WMS
from run_bc import BC
from run_on import ON
from run_yk import YK
import arcgis_common
import ca_provinces
from ca_provinces import PROVINCES, run_region_cfg, TODAY

# QC is WFS/GPKG, not ArcGIS REST — its own module + a run_region config
QC = {"slug": "qc", "name": "Quebec", "dir": "data/qc", "metric_crs": "EPSG:3978",
      "attribution": ("Contains information from SIGEOM (Géologie Québec) and GESTIM "
                      "(titres miniers) under the Open Government Licence – Québec. "
                      "Verify tenure before staking.")}

# order = user's "fastest-open-data first", then the rest
REGIONS_SITE = ([
    {"name": "British Columbia", "dir": "data/bc", "slug": "bc", "live": True},
    {"name": "Ontario", "dir": "data/on", "slug": "on", "live": True},
    {"name": "Yukon", "dir": "data/yk", "slug": "yk", "live": True},
] + [{"name": p["name"], "dir": p["dir"], "slug": p["slug"], "live": True} for p in PROVINCES]
  + [{"name": "Quebec", "dir": "data/qc", "slug": "qc", "live": True}])

APP_REGIONS = [   # combined explorer stays scoped to the flagship regions (size)
    {"dir": "data/bc", "slug": "bc", "name": "British Columbia", "metric": "EPSG:3005", "news": "site/news.json"},
    {"dir": "data/on", "slug": "on", "name": "Ontario", "metric": "EPSG:3161", "news": "site/news_on.json"},
    {"dir": "data/yk", "slug": "yk", "name": "Yukon", "metric": "EPSG:3579", "news": "site/news_yk.json"},
]


def _have(p):
    return os.path.exists(p)


def _bc():
    ingest.run()
    keep = "data/keep/bc_minfile_facts.parquet"
    if _have(keep):
        shutil.copy(keep, "data/bc/minfile_facts.parquet")
    pipeline.run_region(BC)
    build_map.build("data/bc/out", "site/bc.html", wms=BC_WMS)
    daily.build("data/bc", "site", "British Columbia", "EPSG:3005",
                news_path="site/news.json", out_name="daily_bc.html")


def _on():
    if os.environ.get("FULL") or not _have("data/on/claims.parquet"):
        on_ingest.run()
    else:
        for fn, fx in [("mdi", on_ingest.fetch_mdi), ("drillholes", on_ingest.fetch_drill),
                       ("parks", on_ingest.fetch_parks), ("communities", on_ingest.fetch_communities)]:
            if not _have(f"data/on/{fn}.parquet"):
                fx()
    on_prep.prep()
    pipeline.run_region(ON)
    import on_web_facts
    on_web_facts.enrich("data/on")
    build_map.build("data/on/out", "site/on.html", inline_claims=True)
    daily.build("data/on", "site", "Ontario", "EPSG:3161",
                news_path="site/news_on.json", out_name="daily_on.html")


def _yk():
    import yk_ingest
    if not _have("data/yk/claims.parquet") or not _have("data/yk/occurrences.parquet"):
        yk_ingest.run()
    pipeline.run_region(YK)
    build_map.build("data/yk/out", "site/yk.html", inline_claims=True)
    daily.build("data/yk", "site", "Yukon", "EPSG:3579",
                news_path="site/news_yk.json", out_name="daily_yk.html")


def _arcgis_province(cfg):
    def _run():
        if os.environ.get("FULL") or not _have(os.path.join(cfg["dir"], "claims.parquet")) \
                or not _have(os.path.join(cfg["dir"], "occurrences.parquet")):
            arcgis_common.run_fetch(cfg)
        else:
            arcgis_common.boundary(cfg)
        pipeline.run_region(run_region_cfg(cfg))
        build_map.build(os.path.join(cfg["dir"], "out"), f"site/{cfg['slug']}.html", inline_claims=True)
        daily.build(cfg["dir"], "site", cfg["name"], cfg["metric_crs"],
                    news_path=f"site/news_{cfg['slug']}.json", out_name=f"daily_{cfg['slug']}.html")
    return _run


def _qc():
    import qc_ingest
    if os.environ.get("FULL") or not _have("data/qc/claims.parquet") \
            or not _have("data/qc/occurrences.parquet"):
        qc_ingest.run()
    pipeline.run_region({"name": "Quebec", "dir": "data/qc", "metric_crs": "EPSG:3978",
                         "today": TODAY, "inline_claims": True, "attribution": QC["attribution"]})
    build_map.build("data/qc/out", "site/qc.html", inline_claims=True)
    daily.build("data/qc", "site", "Quebec", "EPSG:3978",
                news_path="site/news_qc.json", out_name="daily_qc.html")


def main():
    os.makedirs("site", exist_ok=True)

    try:
        import fetch_prices
        fetch_prices.run()
    except Exception as e:
        print("[build_all] price refresh skipped:", str(e)[:80])

    try:
        import fetch_news
        fetch_news.run(["data/bc", "data/on"])
    except Exception as e:
        print("[build_all] news fetch skipped:", str(e)[:80])

    # region builders in the chosen order
    builders = [("bc", _bc), ("on", _on), ("yk", _yk)]
    builders += [(p["slug"], _arcgis_province(p)) for p in PROVINCES]
    builders += [("qc", _qc)]

    live = []
    for slug, fn in builders:
        try:
            fn()
            live.append(slug)
        except Exception as e:
            print(f"[build_all] region {slug} FAILED, skipping:", str(e)[:140])
            traceback.print_exc()

    regions_site = [r for r in REGIONS_SITE if r["slug"] in live
                    and _have(os.path.join(r["dir"], "out", "leads.geojson"))]
    app_regions = [r for r in APP_REGIONS if r["slug"] in live
                   and _have(os.path.join(r["dir"], "out", "leads.geojson"))]

    build_app.build(app_regions, "site/app.html")
    import build_priority
    build_priority.build("site", regions_site)         # index.html (front page)
    build_site.build("site", regions_site)             # regions.html hub + CSV/XLSX

    # daily email digest across every live region
    import json as _json
    metric = {r["slug"]: r["metric_crs"] for r in [
        {"slug": "bc", "metric_crs": "EPSG:3005"}, {"slug": "on", "metric_crs": "EPSG:3161"},
        {"slug": "yk", "metric_crs": "EPSG:3579"}] + [
        {"slug": p["slug"], "metric_crs": p["metric_crs"]} for p in PROVINCES] + [
        {"slug": "qc", "metric_crs": "EPSG:3978"}]}
    name = {r["slug"]: r["name"] for r in REGIONS_SITE}
    email = {"generated": TODAY, "site": "https://jaydeepdive.github.io/closeology/", "regions": []}
    for slug in live:
        d = f"data/{slug}"
        news = f"site/news_{slug}.json" if slug != "bc" else "site/news.json"
        try:
            dp = daily.payload(d, metric.get(slug, "EPSG:3978"), news)
        except Exception:
            continue
        flagged = [f["properties"] for f in dp["lead_feats"]
                   if f["properties"]["near_a"] or f["properties"]["near_b"]]
        flagged.sort(key=lambda p: -p.get("score", 0))
        email["regions"].append({"slug": slug, "name": name.get(slug, slug.upper()),
                                 "labels": dp["labels"], "counts": dp["counts"],
                                 "edges": dp.get("edges", [])[:20],
                                 "edge_counts": dp.get("edge_counts", {"n": 0, "hot": 0, "open_ha": 0}),
                                 "leads": flagged[:20], "dropped": dp.get("dropped", [])[:25]})
    _json.dump(email, open("site/daily_email.json", "w"))
    tot_edges = sum(len(r["edges"]) for r in email["regions"])
    print(f"[build_all] done ({', '.join(live)}) + daily_email.json ({tot_edges} edge plays)")


if __name__ == "__main__":
    main()
