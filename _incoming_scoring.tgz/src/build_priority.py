"""Unified, cross-jurisdiction priority list: every BC + Ontario lead ranked on
one scale, each showing WHY it sits where it does (the score breakdown) plus all
qualifying detail. Deep Dive-styled (sister site to thedeepdive.ca)."""
import os
import json
import math
import pandas as pd
import site_theme as T
import enrich_facts as E
from config import score_breakdown, metal_bucket, METAL_ORDER


def _num(v, d=0.0):
    try:
        f = float(v)
        return f if f == f else d
    except (TypeError, ValueError):
        return d


def _s(v):
    if v is None:
        return ""
    if isinstance(v, float) and math.isnan(v):
        return ""
    s = str(v)
    return "" if s in ("nan", "None") else s


def _load(csv, juris):
    if not os.path.exists(csv):
        return []
    d = pd.read_csv(csv)
    out = []
    for _, r in d.iterrows():
        status = _s(r.get("status"))
        dopen = bool(r.get("deposit_open"))
        grade = _s(r.get("grade_str"))
        tonnes = _s(r.get("tonnes_str"))
        drill = _s(r.get("drill_highlights"))
        spend = _num(r.get("exploration_spend"))
        conf = _num(r.get("grade_conf"), 1.0)
        lpy = r.get("last_prod_year")
        lpy = None if (lpy is None or str(lpy).strip() in ("", "nan", "None")) else lpy
        pmetal = _s(r.get("primary_metal"))
        bd = score_breakdown(status, dopen, grade, tonnes, bool(drill), spend, conf, lpy, pmetal)
        capsule = _s(r.get("capsule"))
        grade, top_metal = E.sort_grade_by_value(grade)   # highest-$ metal first
        _vt, vparts = E.value_parts(grade)
        drill_top = E.top_intercepts(drill, 3)
        production = _s(r.get("production")) or E.production_summary(capsule, drill, status)
        # dominant metal = the metal contributing the most $/t (else first commodity)
        dom_raw = vparts[0][0] if vparts else (top_metal or _s(r.get("primary_metal")))
        dmetal = metal_bucket(dom_raw) if dom_raw else "Other metallic"
        out.append({
            "value_parts": vparts, "drill_top": drill_top, "production": production,
            "dmetal": dmetal, "last_prod_year": (int(lpy) if lpy not in (None,) and str(lpy).strip().isdigit() else ""),
            "juris": juris, "name": _s(r.get("name")) or "(unnamed)",
            "lead_id": _s(r.get("lead_id")),
            "minfile": _s(r.get("minfile")), "url": _s(r.get("minfile_url")),
            "metal": top_metal or _s(r.get("primary_metal")), "metals": _s(r.get("metals_abbr")),
            "commodity": _s(r.get("commodity")), "status": status, "deposit_open": dopen,
            "hard": _s(r.get("hard_to_stake")).lower() == "true", "grade": grade,
            "size": _s(r.get("deposit_size")) or (tonnes if tonnes else ""),
            "drill": drill[:300], "spend_str": _s(r.get("exploration_spend_str")),
            "operators": _s(r.get("operators")), "last_work": _s(r.get("last_work_year")),
            "community": _s(r.get("nearest_community")), "community_km": _s(r.get("community_km")),
            "encumbrances": _s(r.get("encumbrances")), "cells_ha": _s(r.get("cells_area_ha")),
            "n_cells": _s(r.get("n_cells")), "score": bd["total"], "parts": bd["parts"],
            "lat": _num(r.get("lat")), "lon": _num(r.get("lon")),
        })
    return out


# per-jurisdiction pill colours (fallback grey for any not listed)
PILL = {"BC": "background:#e8f0fe;color:#1a56db;", "ON": "background:#fdeaea;color:#c81e1e;",
        "YK": "background:#eef7ee;color:#2f7d32;", "NL": "background:#e6f4f6;color:#0e7490;",
        "SK": "background:#f3eefe;color:#6d28d9;", "MB": "background:#fef3e2;color:#b45309;",
        "QC": "background:#fce7f3;color:#be185d;", "AB": "background:#e0f2fe;color:#0369a1;",
        "NT": "background:#e9f7f3;color:#0f766e;", "NB": "background:#fdf0e6;color:#9a3412;",
        "NS": "background:#eef2ff;color:#3730a3;"}


def build(site_dir, regions):
    leads = []
    juris = []      # (code, display name) in region order, only those with leads
    for r in regions:
        if not r.get("live"):
            continue
        code = r["slug"].upper()
        rows = _load(os.path.join(r["dir"], "out", "leads.csv"), code)
        if rows:
            leads += rows
            juris.append((code, r["name"]))
    leads.sort(key=lambda x: (-x["score"], not x["deposit_open"]))
    for i, l in enumerate(leads, 1):
        l["rank"] = i
    counts = {c: sum(1 for l in leads if l["juris"] == c) for c, _ in juris}

    # dynamic filter segment + hero radar links + per-juris pill CSS
    segs = ['<button data-j="all" class="on">All ({0})</button>'.format(len(leads))]
    for c, nm in juris:
        segs.append('<button data-j="{0}">{1} ({2})</button>'.format(c, nm, counts[c]))
    radio = "".join('<a class="hbtn ghost" href="daily_{0}.html">{1} radar</a>'.format(c.lower(), nm)
                    for c, nm in juris)
    pill_css = "".join(".p-{0}{{{1}}}".format(c.lower(), PILL.get(c, "background:#eef0f2;color:#444;"))
                       for c, _ in juris)
    names = ", ".join(nm for _, nm in juris[:-1]) + (" and " + juris[-1][1] if len(juris) > 1 else
                                                     (juris[0][1] if juris else ""))

    # dominant-metal filter chips (by highest $/t per lead), ordered by the metal taxonomy
    mcounts = {}
    for l in leads:
        mcounts[l["dmetal"]] = mcounts.get(l["dmetal"], 0) + 1
    order = {m: i for i, m in enumerate(METAL_ORDER)}
    metals_sorted = sorted(mcounts, key=lambda m: (order.get(m, 99), -mcounts[m]))
    PRECIOUS = {"Gold", "Silver"}
    mchips = "".join(
        '<button class="mchip on" data-m="{0}" data-prec="{1}">{0} <span class=mc>{2}</span></button>'.format(
            m, "1" if m in PRECIOUS else "0", mcounts[m]) for m in metals_sorted)

    html = PAGE.format(
        fonts=T.FONTS, css=T.THEME_CSS + "\n" + pill_css,
        header=T.header("index.html"), footer=T.footer(),
        leads_json=json.dumps(leads, separators=(",", ":")),
        segs="".join(segs), radio=radio, region_names=names, mchips=mchips,
    )
    os.makedirs(site_dir, exist_ok=True)
    open(os.path.join(site_dir, "index.html"), "w").write(html)          # front page
    open(os.path.join(site_dir, "priorities.html"), "w").write(html)      # stable alias
    summ = ", ".join("{0} {1}".format(counts[c], c) for c, _ in juris)
    print(f"[priority] index.html (front page) — {len(leads)} leads ({summ})")


PAGE = r"""<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Priority Leads · Project Closeology</title>
{fonts}
<style>{css}
.controls{{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:18px 0 6px;}}
.controls input{{flex:1;min-width:220px;padding:9px 12px;border:1px solid var(--line);border-radius:8px;font-size:14px;}}
.seg{{display:inline-flex;border:1px solid var(--line);border-radius:8px;overflow:hidden;}}
.seg button{{border:0;background:#fff;padding:9px 14px;font-size:13px;font-weight:600;cursor:pointer;color:var(--mut);}}
.seg button.on{{background:var(--red);color:#fff;}}
.count{{color:var(--mut);font-size:13px;}}
.mrow{{display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin:4px 0 2px;}}
.mrow .lbl{{font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--mut);font-weight:700;margin-right:4px;}}
.mchip{{border:1px solid var(--line);background:#fff;color:#2d3748;font-size:12px;font-weight:600;padding:4px 10px;border-radius:20px;cursor:pointer;}}
.mchip.on{{background:var(--ink);color:#fff;border-color:var(--ink);}}
.mchip .mc{{opacity:.6;font-weight:500;margin-left:2px;}}
.mpreset{{border:1px solid var(--line);background:#fff;color:var(--red);font-size:11.5px;font-weight:700;padding:4px 10px;border-radius:20px;cursor:pointer;}}
.lead{{border:1px solid var(--line);border-radius:12px;padding:0;margin:14px 0;overflow:hidden;background:#fff;}}
.lead:hover{{box-shadow:0 3px 14px rgba(0,0,0,.06);}}
.lhead{{display:flex;gap:16px;align-items:flex-start;padding:16px 18px;border-bottom:1px solid var(--line);}}
.rankbox{{flex:0 0 auto;text-align:center;min-width:56px;}}
.rankbox .r{{font-family:'Bitter',serif;font-weight:800;font-size:26px;line-height:1;}}
.rankbox .rl{{font-size:9.5px;letter-spacing:1px;color:var(--mut);text-transform:uppercase;}}
.scorebox{{flex:0 0 auto;text-align:center;min-width:62px;padding:6px 8px;border:1px solid var(--line);border-radius:10px;}}
.scorebox .s{{font-family:'Bitter',serif;font-weight:800;font-size:24px;line-height:1;color:var(--red);}}
.scorebox .sl{{font-size:9px;letter-spacing:.5px;color:var(--mut);text-transform:uppercase;}}
.lmain{{flex:1;min-width:0;}}
.lname{{font-family:'Bitter',serif;font-weight:700;font-size:18px;}}
.pill{{font-size:10px;font-weight:700;padding:2px 8px;border-radius:20px;margin-left:8px;vertical-align:middle;}}
.p-open{{background:#e7f6ec;color:#127a3a;}} .p-hard{{background:#fff4e5;color:#9a5b00;}}
.sub{{color:var(--mut);font-size:13px;margin-top:3px;}}
.chips{{margin-top:7px;}} .chip{{display:inline-block;background:var(--chip);color:#2d3748;font-size:11px;font-weight:600;padding:2px 8px;border-radius:6px;margin:2px 5px 2px 0;}}
.lbody{{display:grid;grid-template-columns:1.05fr 1fr;gap:0;}}
@media (max-width:760px){{.lbody{{grid-template-columns:1fr;}}}}
.why,.facts{{padding:14px 18px;}} .why{{border-right:1px solid var(--line);background:#fcfcfd;}}
@media (max-width:760px){{.why{{border-right:0;border-bottom:1px solid var(--line);}}}}
.sechd{{font-size:11px;letter-spacing:1px;text-transform:uppercase;color:var(--mut);font-weight:700;margin-bottom:8px;}}
.prow{{display:flex;gap:10px;align-items:baseline;margin:5px 0;font-size:13px;}}
.pbadge{{flex:0 0 auto;font-family:'Bitter',serif;font-weight:800;color:var(--red);min-width:34px;}}
.prow .pl{{font-weight:600;}} .prow .pn{{color:var(--mut);}}
.fact{{margin:6px 0;font-size:13px;}} .fact .k{{color:var(--mut);font-weight:600;display:inline-block;min-width:96px;}}
.drill{{font-size:12.5px;color:#374151;background:#fcfcfd;border-left:3px solid var(--red);padding:7px 10px;margin-top:8px;border-radius:0 6px 6px 0;}}
.maplink{{display:inline-block;background:var(--red);color:#fff;font-size:12px;font-weight:600;padding:5px 12px;border-radius:7px;}} .maplink:hover{{text-decoration:none;opacity:.92;}}
.intercept{{font-size:12.5px;padding:5px 10px;margin-top:5px;background:#f0f9f4;border-left:3px solid #127a3a;border-radius:0 6px 6px 0;display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;}}
.intercept .vpt{{color:#127a3a;font-weight:700;white-space:nowrap;}}
.prodbox{{font-size:12.5px;color:#374151;background:#fbf6ef;border-left:3px solid #9a5b00;padding:7px 10px;margin-top:10px;border-radius:0 6px 6px 0;}}
.herolinks{{display:flex;gap:8px;flex-wrap:wrap;margin-top:14px;}}
.hbtn{{background:var(--red);color:#fff;font-size:13px;font-weight:600;padding:8px 14px;border-radius:8px;}} .hbtn:hover{{text-decoration:none;opacity:.92;}}
.hbtn.ghost{{background:#fff;border:1px solid var(--line);color:var(--ink);}}
.empty{{color:var(--mut);padding:30px;text-align:center;}}
</style></head><body>
{header}
<div class="wrap">
  <div class="hero">
    <h1>Priority leads</h1><div class="rule"></div>
    <p>Every {region_names} lead ranked on <b>one common scale</b> — driven by in-situ
       metal value, deposit size, development status, open ground, drilling on record and exploration
       spend. A score of 80 means the same thing in every jurisdiction. Each lead shows exactly why it
       sits where it does.</p>
    <div class="herolinks">
      <a class="hbtn" href="app.html">Interactive map →</a>
      {radio}
    </div>
  </div>
  <div class="controls">
    <input id="q" placeholder="Search name, metal, commodity, community…"/>
    <div class="seg" id="seg">
      {segs}
    </div>
  </div>
  <div class="mrow" id="mrow">
    <span class="lbl">Dominant metal</span>
    <button class="mpreset" data-preset="all">All</button>
    <button class="mpreset" data-preset="precious">Precious only</button>
    <button class="mpreset" data-preset="none">None</button>
    {mchips}
  </div>
  <div class="count" id="count"></div>
  <div id="list"></div>
</div>
{footer}
<script>
const LEADS={leads_json};
const esc=s=>(s==null?'':String(s)).replace(/[&<>]/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;'}}[c]));
let jf='all', q='';
const ALLM=[...new Set(LEADS.map(l=>l.dmetal))];
let selM=new Set(ALLM);   // dominant-metal filter (all on by default)
function card(p){{
  const parts=(p.parts||[]).map(x=>`<div class=prow><span class=pbadge>+${{x.pts}}</span><span><span class=pl>${{esc(x.label)}}.</span> <span class=pn>${{esc(x.note)}}</span></span></div>`).join('');
  const chips=[];
  if(p.metals) chips.push(`<span class=chip>${{esc(p.metals)}}</span>`);
  else if(p.metal) chips.push(`<span class=chip>${{esc(p.metal)}}</span>`);
  if(p.grade) chips.push(`<span class=chip>${{esc(p.grade)}}</span>`);
  const facts=[];
  facts.push(`<div class=fact><span class=k>Status</span>${{esc(p.status)||'—'}}</div>`);
  if(p.commodity) facts.push(`<div class=fact><span class=k>Commodities</span>${{esc(p.commodity)}}</div>`);
  if(p.grade) facts.push(`<div class=fact><span class=k>Grade</span>${{esc(p.grade)}}</div>`);
  if(p.value_parts&&p.value_parts.length) facts.push(`<div class=fact><span class=k>Value split</span>${{p.value_parts.map(x=>esc(x[0])+' <b>$'+x[1]+'</b>').join(' · ')}} <span class=pn>per tonne in-situ</span></div>`);
  if(p.size) facts.push(`<div class=fact><span class=k>Size</span>${{esc(p.size)}}</div>`);
  if(p.spend_str) facts.push(`<div class=fact><span class=k>Expl. spend</span>${{esc(p.spend_str)}}${{p.last_work?(' · last '+esc(p.last_work)):''}}${{p.operators?(' · '+esc(p.operators)):''}}</div>`);
  if(p.community) facts.push(`<div class=fact><span class=k>Nearest town</span>${{esc(p.community)}}${{p.community_km!==''?(' · '+esc(p.community_km)+' km'):''}}</div>`);
  if(p.cells_ha) facts.push(`<div class=fact><span class=k>Open ground</span>${{esc(p.n_cells)}} cell(s) · ${{esc(p.cells_ha)}} ha adjacent</div>`);
  if(p.encumbrances && !p.hard) facts.push(`<div class=fact><span class=k>Nearby</span>${{esc(p.encumbrances)}}</div>`);
  if(p.url) facts.push(`<div class=fact><span class=k>Record</span><a href="${{esc(p.url)}}" target=_blank>${{esc(p.minfile)||'official record'}} ↗</a></div>`);
  const mapurl=`${{p.juris.toLowerCase()}}.html?lat=${{p.lat}}&lon=${{p.lon}}&lead=${{encodeURIComponent(p.lead_id||'')}}`;
  return `<div class=lead>
    <div class=lhead>
      <div class=rankbox><div class=r>${{p.rank}}</div><div class=rl>rank</div></div>
      <div class=scorebox><div class=s>${{p.score}}</div><div class=sl>score</div></div>
      <div class=lmain>
        <div><span class=lname>${{esc(p.name)}}</span>
          <span class="pill p-${{p.juris.toLowerCase()}}">${{p.juris}}</span>
          ${{p.deposit_open?'<span class="pill p-open">deposit open</span>':''}}
          ${{p.hard?'<span class="pill p-hard">harder to stake</span>':''}}</div>
        <div class=sub>${{esc(p.metal)}}${{p.minfile?(' · '+esc(p.minfile)):''}}</div>
        <div class=chips>${{chips.join('')}}</div>
        <div style="margin-top:8px"><a class=maplink href="${{mapurl}}">📍 View on the map</a></div>
      </div>
    </div>
    <div class=lbody>
      <div class=why><div class=sechd>Why it ranks here</div>${{parts}}</div>
      <div class=facts><div class=sechd>Qualifying details</div>${{facts.join('')}}
        ${{p.production?`<div class=prodbox><b>Past production.</b> ${{esc(p.production)}}</div>`:''}}
        ${{(p.drill_top&&p.drill_top.length)?(`<div class=sechd style="margin-top:12px">⛏ Top drill results</div>`+p.drill_top.map(x=>`<div class=intercept><b>${{esc(x.text)}}</b> <span class=vpt>≈ $${{x.vpt}}/t</span></div>`).join('')):(p.drill?`<div class=drill><b>Drill / assay.</b> ${{esc(p.drill)}}${{p.drill.length>=300?'…':''}}</div>`:'')}}
        ${{p.hard?`<div class=drill style="border-left-color:#9a5b00"><b>Staking note:</b> ${{esc(p.encumbrances)||'A conditional / registration reserve applies here — a special staking process is required.'}}</div>`:''}}
      </div>
    </div>
  </div>`;
}}
function render(){{
  const ql=q.toLowerCase();
  const rows=LEADS.filter(p=>(jf==='all'||p.juris===jf) && selM.has(p.dmetal) &&
    (!ql || (p.name+' '+p.metal+' '+p.commodity+' '+p.community+' '+p.metals).toLowerCase().includes(ql)));
  document.getElementById('count').textContent=rows.length+' lead'+(rows.length===1?'':'s')+' shown, ranked by priority';
  document.getElementById('list').innerHTML=rows.length?rows.map(card).join(''):'<div class=empty>No leads match — widen the metal or jurisdiction filter.</div>';
}}
document.getElementById('seg').addEventListener('click',e=>{{const b=e.target.closest('button[data-j]');if(!b)return;
  jf=b.dataset.j;document.querySelectorAll('#seg button').forEach(x=>x.classList.toggle('on',x===b));render();}});
document.getElementById('q').addEventListener('input',e=>{{q=e.target.value;render();}});
// dominant-metal chips + presets
function syncChips(){{document.querySelectorAll('.mchip').forEach(c=>c.classList.toggle('on',selM.has(c.dataset.m)));}}
document.getElementById('mrow').addEventListener('click',e=>{{
  const chip=e.target.closest('.mchip'), pre=e.target.closest('.mpreset');
  if(chip){{const m=chip.dataset.m; selM.has(m)?selM.delete(m):selM.add(m);}}
  else if(pre){{const p=pre.dataset.preset;
    if(p==='all') selM=new Set(ALLM);
    else if(p==='none') selM=new Set();
    else if(p==='precious') selM=new Set(ALLM.filter(m=>m==='Gold'||m==='Silver'));}}
  else return;
  syncChips(); render();
}});
render();
</script></body></html>
"""
